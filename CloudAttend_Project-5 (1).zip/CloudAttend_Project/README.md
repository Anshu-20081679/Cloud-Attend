# CloudAttend — Student Attendance Management System

A responsive front-end prototype inspired by the CloudAttend demo layout.

## Features
- Dashboard attendance counts
- Student list and search
- Add student form
- Mark Present, Absent, or Late by date
- Attendance history
- CSV export
- Local browser storage

## Run
Open `index.html` in a modern browser. No server or installation is required.

## Technology
HTML, CSS, JavaScript, browser LocalStorage.

## Note
This is a recreated project prototype based on the screenshots provided. It is not the original Embarko source code and it does not connect to a cloud database.
